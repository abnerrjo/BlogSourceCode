<?php
class UserModel extends CI_Model {

	public function __construct() {
		$this->load->database();
	}

	function login($login, $password) {
		$this->db->select("*");
		$this->db->from('User');
		$this->db->where('login', $login);
		$this->db->where('password', md5($password));
		$query = $this->db->get();
		return $query->num_rows() > 0;
	}
	
	private function exists($login) {
		$this->db->select("*");
		$this->db->from("User");
		$this->db->where("login", $login);
		$query = $this->db->get();
		return $query->num_rows() > 0;
	}

	function register($name, $login, $password) {
		if ($this->exists($login)) return;
		$this->db->insert('User', array(
			'name' => $name,
			'login' => $login,
			'password' => md5($password)
		));
	}
	
}?>
