<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'form'));
        $this->load->model("usermodel");
        $this->load->library('session');
    }
    
	private function view($page, $data=false) {
		$this->load->view("auth/header.php");
		$this->load->view($page, $data);
		$this->load->view("auth/footer.php");
	}
	
	public function index() {
		if ($this->session->userdata("user")) {
			redirect("success", "refresh");
			return;
		}
		$this->view("auth/login");
	}
	
	public function register() {
		$this->view("auth/register");
	}

	public function fail() {
		$this->view("auth/fail");
	}

	public function success() {
		$data["usuario"] = $this->session->userdata("user");
		$this->view("auth/success", $data);
	}
	
	public function login() {
		$login = $this->input->post("login");
		$password = $this->input->post("password");
		if ($this->usermodel->login($login, $password)) {
			$this->session->set_userdata("user", $login);
			redirect("success", "refresh");
		} else {
			redirect("fail", "refresh");
		}
	}
	
	public function new_register() {
		$login = $this->input->post("login");
		$password = $this->input->post("password");
		$name = $this->input->post("name");
		$this->usermodel->register($name, $login, $password);
		redirect("index", "refresh");
	}
	
	 public function logout() {
    	$this->session->unset_userdata('user');
    	session_destroy();
    	redirect('index', 'refresh');
    }
    
}
