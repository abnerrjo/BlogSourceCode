<p>Olá, <?php echo $usuario; ?>. Você logou com sucesso!</p>
<a href="logout">Clique aqui para deslogar.</a>
