<?php echo form_open('new_register'); ?>
	<input type="text" name="name" placeholder="Digite seu nome" required maxlength="100" autofocus /> 
	<input type="text" name="login" placeholder="Digite seu login" required maxlength="30" />
	<input type="password" name="password" placeholder="Digite sua senha" required maxlength="30" />
	<button type="submit">Cadastrar</button>
</form>
