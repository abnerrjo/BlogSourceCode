<?php echo form_open('login'); ?>
	<input type="text" name="login" placeholder="Digite seu login" required />
	<input type="password" name="password" placeholder="Digite sua senha" required />
	<button type="submit">Entrar</button>
</form>		
<a href="<?php echo base_url(); ?>index.php/register">Não possuí conta? Clique aqui para se cadastrar!</a>
